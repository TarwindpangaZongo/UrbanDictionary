# Urban Dictionary API

This app connects to the Urban Dictionary API. It follows MVVM architecture and displays the terms in a recycler view. It also uses RxJava + Retrofit to make an asynchronous call.

One unit test and one instrumentation test was added.