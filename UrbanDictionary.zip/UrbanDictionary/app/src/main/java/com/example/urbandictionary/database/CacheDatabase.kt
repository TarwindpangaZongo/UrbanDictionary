package com.example.urbandictionary.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(version = 1, entities = [CacheEntity::class])
abstract class CacheDatabase: RoomDatabase() {

    companion object{
        const val DB_NAME: String = "cache.db"
    }
    abstract fun cacheDAO(): CacheDAO
}