package com.example.urbandictionary.viewmodels

import androidx.appcompat.widget.SearchView
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.urbandictionary.database.CacheEntity
import com.example.urbandictionary.model.ApplicationSingleton
import com.example.urbandictionary.model.network.UrbanRepository
import com.example.urbandictionary.model.response.UrbanResponse
import com.example.urbandictionary.model.response.Word
import com.google.gson.Gson
import com.jakewharton.rxbinding.support.v7.widget.RxSearchView
import io.reactivex.disposables.CompositeDisposable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import rx.Notification
import java.net.UnknownHostException
import java.util.*
import java.util.concurrent.TimeUnit

class UrbanViewModel constructor(private val urbanRepository: UrbanRepository) : ViewModel() {
    private val disposable = CompositeDisposable()
    private val stateMutableLiveData = MutableLiveData<AppState>()
    val stateLiveData: LiveData<AppState>
        get() = stateMutableLiveData
    private var loaded = false

    private fun getDefinitions(term: String) {
        stateMutableLiveData.value = AppState.LOADING
        var cachedResponse: String? = null

        val cacheDAO = ApplicationSingleton.cacheDatabase?.cacheDAO()
        viewModelScope.launch {

        cacheDAO?.getCachedResults(term)?.let { cacheEntity ->
            cachedResponse = cacheEntity.toString()
        }
        }


        if (cachedResponse?.trim() == null) {
            disposable.add(
                urbanRepository.getDefinitionListNetwork(term)
                    .subscribe({
                        loaded = true
                        if (it.list.isEmpty()) {
                            stateMutableLiveData.value = AppState.ERROR("No Definitions Retrieved")
                        } else {
                            CoroutineScope(IO).launch {
                                if (cacheDAO?.getNumberOfRows()!! > 19) {
                                    cacheDAO.deleteById()
                                }
                            }
                            CoroutineScope(IO).launch {
                                cacheDAO?.saveResponseToCacheDB(
                                CacheEntity().also { entity ->
//                                    entity.date = Date().time.toString()//TODO: change this
                                    entity.searchTerm = term
                                    entity.searchResponse = Gson().toJson(it)
                                }
                            )
                                stateMutableLiveData.value = AppState.SUCCESS(it.list) }

                        }
                    }, {
                        loaded = true

                        //errors
                        val errorString = when (it) {
                            is UnknownHostException -> "No Internet Connection"
                            else -> it.localizedMessage
                        }
                        stateMutableLiveData.value = AppState.ERROR(errorString)
                    })
            )
        } else {
            val urbanResponse: UrbanResponse =
                Gson().fromJson(cachedResponse, UrbanResponse::class.java)
            //TODO: Use coroutine - remember to also change the main application
            CoroutineScope(IO).launch {
                stateMutableLiveData.value = AppState.SUCCESS(urbanResponse.list)
            }


        }
    }

    fun searchDefinitions(searchView: SearchView) {
        RxSearchView.queryTextChanges(searchView)
            .doOnEach { notification: Notification<in CharSequence?> ->
                val query = notification.value as CharSequence?
                if (query != null && query.length > 4) {
                    getDefinitions(query.toString())
                }
            }
            .debounce(
                300,
                TimeUnit.MILLISECONDS
            ) // to skip intermediate letters
            .retry(3)
            .subscribe()
    }

    override fun onCleared() {
        super.onCleared()
        disposable.clear()
    }

    sealed class AppState {
        object LOADING : AppState()
        data class SUCCESS(val wordsList: MutableList<Word>) : AppState()
        data class ERROR(val message: String) : AppState()
    }
}