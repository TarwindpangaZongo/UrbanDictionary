package com.example.urbandictionary.views

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.urbandictionary.R
import com.example.urbandictionary.injection.Injection
import com.example.urbandictionary.model.response.Word
import com.example.urbandictionary.viewmodels.UrbanViewModel
import com.example.urbandictionary.viewmodels.UrbanViewModelFactory
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    private lateinit var viewModel: UrbanViewModel
    private var wordsAdapter: WordsAdapter =
        WordsAdapter()
    private val injection = Injection()
    private var listOfItems = arrayOf("Thumb Up", "Thumb Down")
    private var spinner: Spinner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = this.sort_spinner
        spinner!!.onItemSelectedListener = this
        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOfItems)
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.adapter = arrayAdapter

        viewModel = ViewModelProvider(
            this,
            UrbanViewModelFactory(injection.provideUserRepo())
        ).get(UrbanViewModel::class.java)

        viewModel.stateLiveData.observe(this, Observer { appState ->
            when (appState) {
                is UrbanViewModel.AppState.LOADING -> displayLoading()
                is UrbanViewModel.AppState.SUCCESS -> displayWords(appState.wordsList)
                is UrbanViewModel.AppState.ERROR -> displayMessage(appState.message)
                else -> displayMessage(getString(R.string.something_went_wrong))
            }
        })

        initRecyclerView()
        wordSearch()
    }

    private fun displayWords(wordsList: MutableList<Word>) {
        // set recycler to eliminate flicker
        wordsAdapter.update(wordsList)

        // set correct visible element
        progressBar.visibility = View.GONE
        rvNews.visibility = View.VISIBLE
        messageText.visibility = View.GONE
    }

    private fun displayLoading() {
        // set correct visible element
        progressBar.visibility = View.VISIBLE
        rvNews.visibility = View.GONE
        messageText.visibility = View.GONE
    }

    private fun displayMessage(message: String) {
        // set correct visible element
        progressBar.visibility = View.GONE
        rvNews.visibility = View.GONE
        messageText.visibility = View.VISIBLE
        //set message
        messageText.text = message
    }

    private fun initRecyclerView() {
        rvNews.layoutManager = LinearLayoutManager(this)
        rvNews.adapter = wordsAdapter
    }

    private fun wordSearch() {
        viewModel.searchDefinitions(word_search)
    }

    override fun onItemSelected(arg0: AdapterView<*>, arg1: View, position: Int, id: Long) {
        if (position == 0) {
            wordsAdapter.sortByThumbsUp()
        } else if (position == 1) {
            wordsAdapter.sortByThumbsDown()
        }
    }

    override fun onNothingSelected(arg0: AdapterView<*>) {
        wordsAdapter.sortByThumbsUp()
    }
}
