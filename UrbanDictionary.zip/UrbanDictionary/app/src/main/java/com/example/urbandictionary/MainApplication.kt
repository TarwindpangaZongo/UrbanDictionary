package com.example.urbandictionary

import android.app.Application
import androidx.room.Room
import com.example.urbandictionary.database.CacheDatabase
import com.example.urbandictionary.model.ApplicationSingleton

class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        ApplicationSingleton.cacheDatabase = Room.databaseBuilder(
            this,
            CacheDatabase::class.java,
            CacheDatabase.DB_NAME
        )
            .allowMainThreadQueries()//TODO: Remove this after adding coroutines
            .build()
    }
}