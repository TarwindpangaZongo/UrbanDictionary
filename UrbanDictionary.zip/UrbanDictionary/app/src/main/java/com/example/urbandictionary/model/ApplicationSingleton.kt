package com.example.urbandictionary.model

import com.example.urbandictionary.database.CacheDatabase

object ApplicationSingleton {

    var cacheDatabase: CacheDatabase? = null

}