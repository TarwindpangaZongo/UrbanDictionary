package com.example.urbandictionary.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CacheDAO {
    @Query("SELECT * FROM cacheTable WHERE searchTerm LIKE :searchTerm")
    suspend fun getCachedResults(searchTerm: String): List<CacheEntity>

    @Insert
    suspend fun saveResponseToCacheDB(cacheEntity: CacheEntity)

    @Query("SELECT COUNT(*) FROM cacheTable")
    suspend fun getNumberOfRows(): Int


    @Query("DELETE FROM cacheTable WHERE cacheID IN (SELECT cacheID FROM cacheTable ORDER BY cacheID ASC LIMIT 1) ")
    suspend fun deleteById()
}

//2 scenarios
// offline
// if the term exist in the  20 entries of the DB, return
// else return NOT FOUND....

// online
// search api,   return a value if fail show ERROR
// if data then
// update the DB -> with a unique entry of a Succesfull search
// show data into the view