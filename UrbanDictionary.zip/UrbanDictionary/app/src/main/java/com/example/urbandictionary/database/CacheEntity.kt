package com.example.urbandictionary.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "CacheTable")
class CacheEntity{

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "cacheID")
    var cacheID: Int = 0

//    @ColumnInfo(name = "date")
//    var date: String = ""

    @ColumnInfo(name = "searchTerm")
    var searchTerm: String = ""

    @ColumnInfo(name = "searchResponse")
    var searchResponse: String = ""
}