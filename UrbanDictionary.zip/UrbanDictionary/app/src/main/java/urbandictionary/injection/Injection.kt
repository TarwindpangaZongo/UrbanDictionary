package com.example.urbandictionary.injection

import com.example.urbandictionary.database.CacheDAO
import com.example.urbandictionary.model.network.MockUrbanRestServiceImpl
import com.example.urbandictionary.model.network.UrbanRepository
import com.example.urbandictionary.model.network.UrbanRepositoryImpl
import com.example.urbandictionary.model.network.remote.UrbanRestService

class Injection {
    private var userRestService: UrbanRestService? = null
    private  var cacheDAO: CacheDAO? = null
    fun provideUserRepo(): UrbanRepository {
        return UrbanRepositoryImpl(provideUrbanRestService())
//        return UrbanRepositoryImpl(provideUrbanRestService(), provideUrbanCache())
    }
//
//    private fun provideUrbanCache(): CacheDAO {
//        if (cacheDAO == null) {
//            cacheDAO  = MockUrbanRestServiceImpl()
//        }
//        return cacheDAO as CacheDAO
//
//    }

    private fun provideUrbanRestService(): UrbanRestService {
        if (userRestService == null) {
            userRestService = MockUrbanRestServiceImpl()
        }
        return UrbanRestService.instance
    }
}